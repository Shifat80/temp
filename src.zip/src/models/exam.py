from dataclasses import dataclass
from datetime import datetime
import sqlite3
from typing import List, Optional

@dataclass
class Exam:
    id: int
    title: str
    subject: str
    duration: int
    total_marks: int
    created_by: int
    
    @staticmethod
    def get_available_exams(student_id: int) -> List['Exam']:
        conn = sqlite3.connect('exam_system.db')
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT id, title, subject, duration, total_marks, created_by
            FROM exams 
            WHERE id NOT IN (
                SELECT exam_id FROM results WHERE student_id = ?
            )
            ORDER BY id DESC
        """, (student_id,))
        
        exams = [Exam(*row) for row in cursor.fetchall()]
        conn.close()
        
        return exams
    
    @staticmethod
    def create_exam(title: str, subject: str, duration: int, created_by: int) -> Optional[int]:
        conn = sqlite3.connect('exam_system.db')
        cursor = conn.cursor()
        
        try:
            cursor.execute("""
                INSERT INTO exams (title, subject, duration, created_by)
                VALUES (?, ?, ?, ?)
            """, (title, subject, duration, created_by))
            
            exam_id = cursor.lastrowid
            conn.commit()
            return exam_id
        except sqlite3.Error:
            return None
        finally:
            conn.close()