from dataclasses import dataclass
import sqlite3
from typing import Optional
from utils.auth import Auth

@dataclass
class User:
    id: int
    username: str
    name: str

    @staticmethod
    def register_student(username: str, password: str, name: str, class_name: str) -> Optional[int]:
        hashed_password = Auth.hash_password(password)

        conn = sqlite3.connect('exam_system.db')
        cursor = conn.cursor()

        try:
            cursor.execute("""
                INSERT INTO students (username, password, name, class)
                VALUES (?, ?, ?, ?)
            """, (username, hashed_password, name, class_name))

            student_id = cursor.lastrowid
            conn.commit()
            return student_id
        except sqlite3.IntegrityError:
            return None
        finally:
            conn.close()

    @staticmethod
    def register_teacher(username: str, password: str, name: str, subject: str) -> Optional[int]:
        hashed_password = Auth.hash_password(password)

        conn = sqlite3.connect('exam_system.db')
        cursor = conn.cursor()

        try:
            cursor.execute("""
                INSERT INTO admins (username, password, name, subject)
                VALUES (?, ?, ?, ?)
            """, (username, hashed_password, name, subject))

            teacher_id = cursor.lastrowid
            conn.commit()
            return teacher_id
        except sqlite3.IntegrityError:
            return None
        finally:
            conn.close()