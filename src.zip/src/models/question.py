from dataclasses import dataclass
import sqlite3
from typing import List, Optional

@dataclass
class Question:
    id: int
    exam_id: int
    question: str
    option_a: str
    option_b: str
    option_c: str
    option_d: str
    correct_answer: str
    marks: int
    
    @staticmethod
    def get_exam_questions(exam_id: int) -> List['Question']:
        conn = sqlite3.connect('exam_system.db')
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT id, exam_id, question, option_a, option_b, option_c, option_d, 
                   correct_answer, marks
            FROM questions
            WHERE exam_id = ?
            ORDER BY id
        """, (exam_id,))
        
        questions = [Question(*row) for row in cursor.fetchall()]
        conn.close()
        
        return questions
    
    @staticmethod
    def add_question(exam_id: int, question: str, options: List[str], 
                    correct_answer: str, marks: int = 1) -> Optional[int]:
        if len(options) != 4:
            return None
            
        conn = sqlite3.connect('exam_system.db')
        cursor = conn.cursor()
        
        try:
            cursor.execute("""
                INSERT INTO questions (exam_id, question, option_a, option_b, 
                                     option_c, option_d, correct_answer, marks)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (exam_id, question, *options, correct_answer, marks))
            
            question_id = cursor.lastrowid
            conn.commit()
            return question_id
        except sqlite3.Error:
            return None
        finally:
            conn.close()