from dataclasses import dataclass
from datetime import datetime
import sqlite3
from typing import List, Optional

@dataclass
class Result:
    id: int
    student_id: int
    exam_id: int
    score: float
    date: datetime
    
    @staticmethod
    def get_student_results(student_id: int) -> List['Result']:
        conn = sqlite3.connect('exam_system.db')
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT id, student_id, exam_id, score, date
            FROM results
            WHERE student_id = ?
            ORDER BY date DESC
        """, (student_id,))
        
        results = []
        for row in cursor.fetchall():
            id_, student_id, exam_id, score, date_str = row
            date = datetime.strptime(date_str, '%Y-%m-%d %H:%M:%S')
            results.append(Result(id_, student_id, exam_id, score, date))
            
        conn.close()
        return results
    
    @staticmethod
    def save_result(student_id: int, exam_id: int, score: float) -> Optional[int]:
        conn = sqlite3.connect('exam_system.db')
        cursor = conn.cursor()
        
        try:
            cursor.execute("""
                INSERT INTO results (student_id, exam_id, score, date)
                VALUES (?, ?, ?, datetime('now'))
            """, (student_id, exam_id, score))
            
            result_id = cursor.lastrowid
            conn.commit()
            return result_id
        except sqlite3.Error:
            return None
        finally:
            conn.close()