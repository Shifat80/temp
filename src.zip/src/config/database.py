import sqlite3
import os

class DatabaseConfig:
    DB_NAME = 'exam_system.db'
    
    @classmethod
    def init_database(cls):
        if os.path.exists(cls.DB_NAME):
            os.remove(cls.DB_NAME)
            
        conn = sqlite3.connect(cls.DB_NAME)
        cursor = conn.cursor()
        
        # Create tables
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS admins (
            id INTEGER PRIMARY KEY,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            name TEXT NOT NULL,
            subject TEXT
        )''')

        cursor.execute('''
        CREATE TABLE IF NOT EXISTS students (
            id INTEGER PRIMARY KEY,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            name TEXT NOT NULL,
            class TEXT NOT NULL,
            email TEXT,
            phone TEXT,
            bio TEXT,
            profile_pic BLOB
        )''')

        cursor.execute('''
        CREATE TABLE IF NOT EXISTS teachers (
            id INTEGER PRIMARY KEY,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            name TEXT NOT NULL,
            subject TEXT NOT NULL
        )''')

        cursor.execute('''
        CREATE TABLE IF NOT EXISTS exams (
            id INTEGER PRIMARY KEY,
            title TEXT NOT NULL,
            subject TEXT NOT NULL,
            duration INTEGER NOT NULL,
            total_marks INTEGER NOT NULL DEFAULT 100,
            created_by INTEGER,
            FOREIGN KEY (created_by) REFERENCES admins (id)
        )''')

        cursor.execute('''
        CREATE TABLE IF NOT EXISTS questions (
            id INTEGER PRIMARY KEY,
            exam_id INTEGER,
            question TEXT NOT NULL,
            option_a TEXT NOT NULL,
            option_b TEXT NOT NULL,
            option_c TEXT NOT NULL,
            option_d TEXT NOT NULL,
            correct_answer TEXT NOT NULL,
            marks INTEGER NOT NULL DEFAULT 1,
            FOREIGN KEY (exam_id) REFERENCES exams (id)
        )''')

        cursor.execute('''
        CREATE TABLE IF NOT EXISTS results (
            id INTEGER PRIMARY KEY,
            student_id INTEGER,
            exam_id INTEGER,
            score INTEGER,
            date TEXT,
            FOREIGN KEY (student_id) REFERENCES students (id),
            FOREIGN KEY (exam_id) REFERENCES exams (id)
        )''')

        conn.commit()
        conn.close()