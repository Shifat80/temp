from tkinter import messagebox

class MessageUtils:
    """Utility class for displaying messages"""
    
    @staticmethod
    def show_error(message):
        messagebox.showerror("Error", message)
    
    @staticmethod
    def show_success(message):
        messagebox.showinfo("Success", message)
    
    @staticmethod
    def show_warning(message):
        messagebox.showwarning("Warning", message)
    
    @staticmethod
    def confirm_action(message):
        return messagebox.askyesno("Confirm", message)