import hashlib
import sqlite3
from typing import Optional, Tuple

class Auth:
    @staticmethod
    def hash_password(password: str) -> str:
        return hashlib.sha256(password.encode()).hexdigest()
    
    @staticmethod
    def verify_student(username: str, password: str) -> Optional[Tuple[int, str]]:
        hashed_password = Auth.hash_password(password)
        
        conn = sqlite3.connect('exam_system.db')
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT id, name FROM students
            WHERE username = ? AND password = ?
        """, (username, hashed_password))
        
        result = cursor.fetchone()
        conn.close()
        
        return result if result else None
    
    @staticmethod
    def verify_teacher(username: str, password: str) -> Optional[Tuple[int, str]]:
        hashed_password = Auth.hash_password(password)
        
        conn = sqlite3.connect('exam_system.db')
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT id, name FROM admins
            WHERE username = ? AND password = ?
        """, (username, hashed_password))
        
        result = cursor.fetchone()
        conn.close()
        
        return result if result else None