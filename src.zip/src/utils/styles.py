from tkinter import ttk

class StyleConfig:
    COLORS = {
        'bg_dark': '#0A192F',
        'sidebar': '#112240',
        'content': '#1A2744',
        'accent1': '#64FFDA',
        'accent2': '#8892B0',
        'text': '#E6F1FF',
        'text_secondary': '#8892B0',
        'hover': '#233554',
        'success': '#4CAF50',
        'warning': '#FFA726',
        'error': '#EF5350'
    }
    
    @classmethod
    def configure_styles(cls, style: ttk.Style):
        style.theme_use('clam')
        
        # Configure common styles
        style.configure("Sidebar.TFrame", background=cls.COLORS['sidebar'])
        style.configure("Content.TFrame", background=cls.COLORS['content'])
        style.configure("Card.TFrame", background=cls.COLORS['sidebar'])
        
        style.configure("Title.TLabel",
                       background=cls.COLORS['content'],
                       foreground=cls.COLORS['text'],
                       font=('Segoe UI', 24, 'bold'))
                       
        style.configure("Subtitle.TLabel",
                       background=cls.COLORS['content'],
                       foreground=cls.COLORS['text_secondary'],
                       font=('Segoe UI', 14))
                       
        style.configure("Card.TLabel",
                       background=cls.COLORS['sidebar'],
                       foreground=cls.COLORS['text'],
                       font=('Segoe UI', 12))
                       
        style.configure("Custom.TButton",
                       background=cls.COLORS['accent1'],
                       foreground=cls.COLORS['bg_dark'],
                       font=('Segoe UI', 11),
                       padding=(20, 10))
                       
        # Configure Treeview styles
        style.configure("Timeline.Treeview",
                       background=cls.COLORS['content'],
                       foreground=cls.COLORS['text'],
                       fieldbackground=cls.COLORS['content'],
                       borderwidth=0)
                       
        style.configure("Timeline.Treeview.Heading",
                       background=cls.COLORS['sidebar'],
                       foreground=cls.COLORS['text'],
                       borderwidth=0)