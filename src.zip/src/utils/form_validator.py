class FormValidator:
    """Utility class for form validation"""
    
    @staticmethod
    def validate_required_fields(fields):
        """Check if all required fields are filled"""
        return all(field.strip() for field in fields)
    
    @staticmethod
    def validate_username(username):
        """Validate username format"""
        username = username.strip()
        return len(username) >= 3 and username.isalnum()
    
    @staticmethod
    def validate_password(password):
        """Validate password strength"""
        return len(password) >= 6