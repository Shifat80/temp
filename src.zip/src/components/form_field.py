import tkinter as tk
from tkinter import ttk

class FormField:
    """A reusable form field component that combines a label and entry"""
    
    def __init__(self, parent, label_text, is_password=False, width=40):
        self.frame = ttk.Frame(parent)
        
        # Label
        self.label = ttk.Label(
            self.frame,
            text=label_text,
            style="Subtitle.TLabel"
        )
        self.label.pack(anchor='w')
        
        # Entry
        self.entry = ttk.Entry(
            self.frame,
            width=width,
            show="*" if is_password else ""
        )
        self.entry.pack(fill='x', pady=(0, 15))
    
    def pack(self, **kwargs):
        self.frame.pack(**kwargs)
    
    def grid(self, **kwargs):
        self.frame.grid(**kwargs)
    
    def get(self):
        return self.entry.get().strip()
    
    def set(self, value):
        self.entry.delete(0, tk.END)
        self.entry.insert(0, value)