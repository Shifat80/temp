from tkinter import ttk
from src.components.action_button import ActionButton

class BaseForm:
    """Base class for forms with common functionality"""
    
    def __init__(self, root, title):
        self.root = root
        self.root.title(title)
        
        # Main container
        self.main_container = ttk.Frame(root, style="Content.TFrame")
        self.main_container.pack(fill='both', expand=True)
        
        # Center container
        self.center_container = ttk.Frame(self.main_container, style="Content.TFrame")
        self.center_container.pack(fill='both', expand=True, padx=20, pady=20)
        
        # Content frame
        self.content_frame = ttk.Frame(self.center_container, style="Card.TFrame")
        self.content_frame.pack(fill='both', expand=True, padx=20, pady=20)
        
        # Header
        ttk.Label(
            self.content_frame,
            text=title,
            style="Title.TLabel"
        ).pack(pady=30)
        
        # Form frame
        self.form_frame = ttk.Frame(self.content_frame, style="Content.TFrame")
        self.form_frame.pack(padx=50, pady=20)
        
        # Button frame
        self.button_frame = ttk.Frame(self.content_frame, style="Content.TFrame")
        self.button_frame.pack(pady=20)
    
    def add_button(self, text, command, side='left'):
        """Add a button to the button frame"""
        ActionButton(
            self.button_frame,
            text=text,
            command=command
        ).pack(side=side, padx=10)
    
    def destroy(self):
        """Clean up and destroy the form"""
        self.main_container.destroy()