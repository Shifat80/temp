from tkinter import ttk

class ActionButton:
    """A reusable styled button component"""
    
    def __init__(self, parent, text, command, style="Custom.TButton"):
        self.button = ttk.Button(
            parent,
            text=text,
            style=style,
            command=command
        )
    
    def pack(self, **kwargs):
        self.button.pack(**kwargs)
    
    def grid(self, **kwargs):
        self.button.grid(**kwargs)