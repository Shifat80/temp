import tkinter as tk
from tkinter import ttk
from views.login import StudentLogin, TeacherLogin
from views.registration import StudentRegistration, TeacherRegistration
from utils.styles import StyleConfig


class UserTypeSelection:
    def __init__(self, root):
        self.root = root
        self.root.title("Student Portal")
        self.root.state('zoomed')

        # Configure styles
        self.style = ttk.Style()
        StyleConfig.configure_styles(self.style)

        # Main container
        self.main_container = ttk.Frame(root, style="Content.TFrame")
        self.main_container.pack(fill='both', expand=True)

        # Header section
        self.create_header()

        # Cards container
        self.create_cards()

    def create_header(self):
        header_frame = ttk.Frame(self.main_container, style="Content.TFrame")
        header_frame.pack(fill='x', pady=(50, 30))

        ttk.Label(header_frame,
                 text="Welcome to Examination System",
                 style="Title.TLabel").pack(anchor='center')

        ttk.Label(header_frame,
                 text="Choose your role to get started",
                 style="Subtitle.TLabel").pack(anchor='center', pady=10)

    def create_cards(self):
        cards_frame = ttk.Frame(self.main_container, style="Content.TFrame")
        cards_frame.pack(expand=True, fill='both', padx=100)
        cards_frame.grid_columnconfigure(0, weight=1)
        cards_frame.grid_columnconfigure(1, weight=1)

        # Teacher card
        self.create_role_card(cards_frame, 0, "👨‍🏫 Teacher Access",
                            "Create and manage exams",
                            self.show_teacher_login,
                            self.show_teacher_register)

        # Student card
        self.create_role_card(cards_frame, 1, "👨‍🎓 Student Access",
                            "Take exams and view results",
                            self.show_student_login,
                            self.show_student_register)

    def create_role_card(self, parent, column, title, description,
                        login_command, register_command):
        card = ttk.Frame(parent, style="Card.TFrame")
        card.grid(row=0, column=column, padx=20, pady=20, sticky='nsew')

        ttk.Label(card,
                 text=title,
                 style="Card.TLabel").pack(pady=(20, 10))

        ttk.Label(card,
                 text=description,
                 style="Card.TLabel",
                 foreground=StyleConfig.COLORS['text_secondary']).pack(pady=(0, 20))

        button_frame = ttk.Frame(card, style="Card.TFrame")
        button_frame.pack(pady=(0, 20))

        ttk.Button(button_frame,
                  text="Login",
                  style="Custom.TButton",
                  command=login_command).pack(side='left', padx=5)

        ttk.Button(button_frame,
                  text="Register",
                  style="Custom.TButton",
                  command=register_command).pack(side='left', padx=5)

    def show_teacher_login(self):
        self.main_container.destroy()
        TeacherLogin(self.root)

    def show_teacher_register(self):
        self.main_container.destroy()
        TeacherRegistration(self.root)

    def show_student_login(self):
        self.main_container.destroy()
        StudentLogin(self.root)

    def show_student_register(self):
        self.main_container.destroy()
        StudentRegistration(self.root)

if __name__ == "__main__":
    root = tk.Tk()
    root.configure(bg=StyleConfig.COLORS['bg_dark'])
    app = UserTypeSelection(root)
    root.mainloop()