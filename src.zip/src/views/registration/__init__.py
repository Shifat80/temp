from .student_registration import StudentRegistration
from .teacher_registration import TeacherRegistration

__all__ = ['StudentRegistration', 'TeacherRegistration']