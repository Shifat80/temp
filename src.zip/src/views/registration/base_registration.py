from tkinter import ttk
from components import BaseForm, FormField
from utils.form_validator import FormValidator
from utils.message_utils import MessageUtils

class BaseRegistration(BaseForm):
    """Base class for registration views with common functionality"""

    def __init__(self, root, title):
        super().__init__(root, title)

        # Create form fields
        self.username_field = FormField(
            self.form_frame,
            "Username"
        )
        self.username_field.pack(fill='x')

        self.password_field = FormField(
            self.form_frame,
            "Password",
            is_password=True
        )
        self.password_field.pack(fill='x')

        self.name_field = FormField(
            self.form_frame,
            "Full Name"
        )
        self.name_field.pack(fill='x')

        # Add buttons
        self.add_button("Register", self.register)
        self.add_button("Back", self.go_back)

    def validate_registration(self):
        """Validate registration fields"""
        username = self.username_field.get()
        password = self.password_field.get()
        name = self.name_field.get()

        if not FormValidator.validate_required_fields([username, password, name]):
            MessageUtils.show_error("All fields are required!")
            return False

        if not FormValidator.validate_username(username):
            MessageUtils.show_error("Username must be at least 3 characters and alphanumeric!")
            return False

        if not FormValidator.validate_password(password):
            MessageUtils.show_error("Password must be at least 6 characters!")
            return False

        return True

    def register(self):
        """To be implemented by subclasses"""
        raise NotImplementedError

    def go_back(self):
        """To be implemented by subclasses"""
        raise NotImplementedError