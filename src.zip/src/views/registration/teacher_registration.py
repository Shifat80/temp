from models.user import User
from utils.message_utils import MessageUtils
from views.login.teacher_login import TeacherLogin
from .base_registration import BaseRegistration
from components import FormField

class TeacherRegistration(BaseRegistration):
    def __init__(self, root):
        super().__init__(root, "Teacher Registration")

        # Add teacher-specific fields
        self.subject_field = self.add_subject_field()

    def add_subject_field(self):
        """Add subject field specific to teacher registration"""
        subject_field = FormField(
            self.form_frame,
            "Subject"
        )
        subject_field.pack(fill='x')
        return subject_field

    def register(self):
        if not self.validate_registration():
            return

        # Get field values
        username = self.username_field.get()
        password = self.password_field.get()
        name = self.name_field.get()
        subject = self.subject_field.get()

        if not subject:
            MessageUtils.show_error("Subject field is required!")
            return

        # Register teacher
        teacher_id = User.register_teacher(username, password, name, subject)

        if teacher_id:
            MessageUtils.show_success("Registration successful! You can now login.")
            self.destroy()
            TeacherLogin(self.root)
        else:
            MessageUtils.show_error("Username already exists")

    def go_back(self):
        from main import UserTypeSelection
        self.destroy()
        UserTypeSelection(self.root)