from models.user import User
from utils.message_utils import MessageUtils
from views.login.student_login import StudentLogin
from .base_registration import BaseRegistration
from components import FormField
class StudentRegistration(BaseRegistration):
    def __init__(self, root):
        super().__init__(root, "Student Registration")

        # Add student-specific fields
        self.class_field = self.add_class_field()

    def add_class_field(self):
        """Add class field specific to student registration"""
        class_field = FormField(
            self.form_frame,
            "Class"
        )
        class_field.pack(fill='x')
        return class_field

    def register(self):
        if not self.validate_registration():
            return

        # Get field values
        username = self.username_field.get()
        password = self.password_field.get()
        name = self.name_field.get()
        class_name = self.class_field.get()

        if not class_name:
            MessageUtils.show_error("Class field is required!")
            return

        # Register student
        student_id = User.register_student(username, password, name, class_name)

        if student_id:
            MessageUtils.show_success("Registration successful! You can now login.")
            self.destroy()
            StudentLogin(self.root)
        else:
            MessageUtils.show_error("Username already exists")

    def go_back(self):
        from main import UserTypeSelection
        self.destroy()
        UserTypeSelection(self.root)