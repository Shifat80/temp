import tkinter as tk
from tkinter import ttk
import sqlite3
from datetime import datetime
from utils.message_utils import MessageUtils
from models.question import Question
from models.result import Result

class ExamInterface:
    """Interface for taking exams"""

    def __init__(self, root, student_id, exam_id):
        self.root = root
        self.student_id = student_id
        self.exam_id = exam_id
        self.current_question = 0
        self.answers = {}

        self.load_exam_details()
        self.setup_interface()
        self.load_questions()
        self.show_current_question()

    def load_exam_details(self):
        """Load exam information from database"""
        conn = sqlite3.connect('exam_system.db')
        cursor = conn.cursor()

        cursor.execute("""
            SELECT title, duration, total_marks
            FROM exams WHERE id = ?
        """, (self.exam_id,))

        self.exam_details = cursor.fetchone()
        conn.close()

        if not self.exam_details:
            MessageUtils.show_error("Failed to load exam details")
            self.root.destroy()
            return

    def setup_interface(self):
        """Set up the exam interface"""
        self.root.title(f"Exam: {self.exam_details[0]}")
        self.root.state('zoomed')

        # Main container
        self.main_frame = ttk.Frame(self.root, style="Content.TFrame")
        self.main_frame.pack(fill='both', expand=True, padx=20, pady=20)

        # Header
        header_frame = ttk.Frame(self.main_frame, style="Content.TFrame")
        header_frame.pack(fill='x', pady=(0, 20))

        ttk.Label(header_frame,
                 text=self.exam_details[0],
                 style="Title.TLabel").pack(side='left')

        self.timer_label = ttk.Label(header_frame,
                                   text=f"Time Remaining: {self.exam_details[1]}:00",
                                   style="Card.TLabel")
        self.timer_label.pack(side='right')

        # Question frame
        self.question_frame = ttk.Frame(self.main_frame, style="Card.TFrame")
        self.question_frame.pack(fill='both', expand=True, padx=20, pady=20)

        # Navigation buttons
        nav_frame = ttk.Frame(self.main_frame, style="Content.TFrame")
        nav_frame.pack(fill='x', pady=20)

        ttk.Button(nav_frame,
                  text="Previous",
                  style="Custom.TButton",
                  command=self.prev_question).pack(side='left')

        ttk.Button(nav_frame,
                  text="Next",
                  style="Custom.TButton",
                  command=self.next_question).pack(side='left', padx=10)

        ttk.Button(nav_frame,
                  text="Submit Exam",
                  style="Custom.TButton",
                  command=self.submit_exam).pack(side='right')

        # Start timer
        self.remaining_time = self.exam_details[1] * 60  # Convert to seconds
        self.update_timer()

    def load_questions(self):
        """Load exam questions"""
        self.questions = Question.get_exam_questions(self.exam_id)
        if not self.questions:
            MessageUtils.show_error("No questions found for this exam")
            self.root.destroy()

    def show_current_question(self):
        """Display current question"""
        # Clear previous question
        for widget in self.question_frame.winfo_children():
            widget.destroy()

        question = self.questions[self.current_question]

        # Question text
        ttk.Label(self.question_frame,
                 text=f"Question {self.current_question + 1} of {len(self.questions)}",
                 style="Card.TLabel").pack(anchor='w', pady=(0, 10))

        ttk.Label(self.question_frame,
                 text=question.question,
                 style="Card.TLabel",
                 wraplength=800).pack(anchor='w', pady=(0, 20))

        # Options
        self.selected_answer = tk.StringVar(value=self.answers.get(question.id, ''))
        options = [
            ('A', question.option_a),
            ('B', question.option_b),
            ('C', question.option_c),
            ('D', question.option_d)
        ]

        for opt_label, opt_text in options:
            ttk.Radiobutton(self.question_frame,
                          text=f"{opt_label}. {opt_text}",
                          variable=self.selected_answer,
                          value=opt_label,
                          style="Custom.TRadiobutton",
                          command=lambda q=question: self.save_answer(q.id)
                          ).pack(anchor='w', pady=5)

    def save_answer(self, question_id):
        """Save the selected answer"""
        self.answers[question_id] = self.selected_answer.get()

    def next_question(self):
        """Move to next question"""
        if self.current_question < len(self.questions) - 1:
            self.current_question += 1
            self.show_current_question()

    def prev_question(self):
        """Move to previous question"""
        if self.current_question > 0:
            self.current_question -= 1
            self.show_current_question()

    def update_timer(self):
        """Update the timer display"""
        if self.remaining_time <= 0:
            self.submit_exam()
            return

        minutes = self.remaining_time // 60
        seconds = self.remaining_time % 60
        self.timer_label.config(text=f"Time Remaining: {minutes:02d}:{seconds:02d}")

        self.remaining_time -= 1
        self.root.after(1000, self.update_timer)

    def calculate_score(self):
        """Calculate exam score"""
        total_score = 0
        total_marks = 0

        for question in self.questions:
            total_marks += question.marks
            if self.answers.get(question.id) == question.correct_answer:
                total_score += question.marks

        return (total_score / total_marks) * 100 if total_marks > 0 else 0

    def submit_exam(self):
        """Submit the exam"""
        if self.remaining_time > 0 and not MessageUtils.confirm_action(
            "Are you sure you want to submit the exam?"
        ):
            return

        score = self.calculate_score()

        # Save result
        if Result.save_result(self.student_id, self.exam_id, score):
            MessageUtils.show_success(
                f"Exam submitted successfully!\nYour score: {score:.2f}%"
            )
            self.root.destroy()
        else:
            MessageUtils.show_error("Failed to save exam result")