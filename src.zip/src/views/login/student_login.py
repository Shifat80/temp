from utils.auth import Auth
from utils.message_utils import MessageUtils
from views.dashboard import StudentDashboard
from .base_login import BaseLogin

class StudentLogin(BaseLogin):
    def __init__(self, root):
        super().__init__(root, "Student Login")

    def login(self):
        if not self.validate_login():
            return

        student = Auth.verify_student(
            self.username_field.get(),
            self.password_field.get()
        )

        if student:
            MessageUtils.show_success(f"Welcome {student[1]}!")
            self.destroy()
            StudentDashboard(self.root, student[0], self)
        else:
            MessageUtils.show_error("Invalid username or password!")

    def go_back(self):
        from main import UserTypeSelection
        self.destroy()
        UserTypeSelection(self.root)