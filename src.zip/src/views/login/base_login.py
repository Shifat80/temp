from tkinter import ttk
from components import BaseForm, FormField
from utils.form_validator import FormValidator
from utils.message_utils import MessageUtils

class BaseLogin(BaseForm):
    """Base class for login views with common functionality"""

    def __init__(self, root, title):
        super().__init__(root, title)

        # Create form fields
        self.username_field = FormField(
            self.form_frame,
            "Username"
        )
        self.username_field.pack(fill='x')

        self.password_field = FormField(
            self.form_frame,
            "Password",
            is_password=True
        )
        self.password_field.pack(fill='x')

        # Add buttons
        self.add_button("Login", self.login)
        self.add_button("Back", self.go_back)

    def validate_login(self):
        """Validate login fields"""
        username = self.username_field.get()
        password = self.password_field.get()

        if not FormValidator.validate_required_fields([username, password]):
            MessageUtils.show_error("Both fields are required!")
            return False

        if not FormValidator.validate_username(username):
            MessageUtils.show_error("Invalid username format!")
            return False

        return True

    def login(self):
        """To be implemented by subclasses"""
        raise NotImplementedError

    def go_back(self):
        """To be implemented by subclasses"""
        raise NotImplementedError