import tkinter as tk
from utils.auth import Auth
from utils.message_utils import MessageUtils
from views.dashboard import TeacherDashboard
from .base_login import BaseLogin

class TeacherLogin(BaseLogin):
    def __init__(self, root):
        super().__init__(root, "Teacher Login")

    def login(self):
        if not self.validate_login():
            return

        teacher = Auth.verify_teacher(
            self.username_field.get(),
            self.password_field.get()
        )

        if teacher:
            self.root.withdraw()
            admin_window = tk.Toplevel()
            TeacherDashboard(admin_window, teacher[0], self.root)
        else:
            MessageUtils.show_error("Invalid credentials")

    def go_back(self):
        from main import UserTypeSelection
        self.destroy()
        UserTypeSelection(self.root)