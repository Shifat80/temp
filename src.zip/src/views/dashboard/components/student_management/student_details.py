import tkinter as tk
from tkinter import ttk
import sqlite3
from utils.message_utils import MessageUtils

class StudentDetails:
    """Component for viewing detailed student information"""

    def __init__(self, parent, student_id):
        self.parent = parent
        self.student_id = student_id
        self.setup_view()
        self.load_student_data()

    def setup_view(self):
        """Set up the student details view"""
        # Create frames
        self.info_frame = ttk.Frame(self.parent, style="Card.TFrame")
        self.info_frame.pack(fill='both', expand=True, padx=20, pady=20)

        self.results_frame = ttk.Frame(self.parent, style="Card.TFrame")
        self.results_frame.pack(fill='both', expand=True, padx=20, pady=20)

    def load_student_data(self):
        """Load student data from database"""
        try:
            conn = sqlite3.connect('exam_system.db')
            cursor = conn.cursor()

            # Get student info
            cursor.execute("""
                SELECT name, class, email, phone, bio
                FROM students
                WHERE id = ?
            """, (self.student_id,))

            student = cursor.fetchone()

            if student:
                self.display_student_info(student)

                # Get exam results
                cursor.execute("""
                    SELECT e.title, r.score, r.date
                    FROM results r
                    JOIN exams e ON r.exam_id = e.id
                    WHERE r.student_id = ?
                    ORDER BY r.date DESC
                """, (self.student_id,))

                results = cursor.fetchall()
                self.display_results(results)

            conn.close()

        except sqlite3.Error as e:
            MessageUtils.show_error(f"Failed to load student data: {str(e)}")

    def display_student_info(self, student):
        """Display student information"""
        ttk.Label(self.info_frame,
                 text="Student Information",
                 style="Title.TLabel").pack(anchor='w', pady=(0, 20))

        fields = [
            ("Name:", student[0]),
            ("Class:", student[1]),
            ("Email:", student[2] or "Not provided"),
            ("Phone:", student[3] or "Not provided"),
            ("Bio:", student[4] or "No bio available")
        ]

        for label, value in fields:
            field_frame = ttk.Frame(self.info_frame, style="Card.TFrame")
            field_frame.pack(fill='x', pady=5)

            ttk.Label(field_frame,
                     text=label,
                     style="Card.TLabel",
                     width=15).pack(side='left')

            ttk.Label(field_frame,
                     text=value,
                     style="Card.TLabel").pack(side='left', padx=10)

    def display_results(self, results):
        """Display student's exam results"""
        ttk.Label(self.results_frame,
                 text="Exam Results",
                 style="Title.TLabel").pack(anchor='w', pady=(0, 20))

        if not results:
            ttk.Label(self.results_frame,
                     text="No exam results available",
                     style="Card.TLabel").pack(anchor='w')
            return

        # Create treeview for results
        columns = ('Exam', 'Score', 'Date')
        tree = ttk.Treeview(
            self.results_frame,
            columns=columns,
            show='headings',
            style="Timeline.Treeview"
        )

        for col in columns:
            tree.heading(col, text=col)
            tree.column(col, width=150)

        for result in results:
            tree.insert('', 'end', values=(
                result[0],
                f"{result[1]:.2f}%",
                result[2]
            ))

        tree.pack(fill='both', expand=True)