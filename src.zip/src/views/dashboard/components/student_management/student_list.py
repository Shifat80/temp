import tkinter as tk
from tkinter import ttk
import sqlite3
from utils.message_utils import MessageUtils

class StudentList:
    """Component for displaying and managing students"""

    def __init__(self, parent):
        self.parent = parent
        self.setup_list()

    def setup_list(self):
        """Set up the student list view"""
        columns = ('ID', 'Name', 'Class', 'Email', 'Phone')
        self.tree = ttk.Treeview(
            self.parent,
            columns=columns,
            show='headings',
            style="Timeline.Treeview"
        )

        # Configure columns
        widths = {'ID': 50, 'Name': 200, 'Class': 100, 'Email': 200, 'Phone': 150}
        for col, width in widths.items():
            self.tree.heading(col, text=col)
            self.tree.column(col, width=width)

        # Add scrollbar
        scrollbar = ttk.Scrollbar(self.parent, orient='vertical', command=self.tree.yview)
        self.tree.configure(yscrollcommand=scrollbar.set)

        # Pack widgets
        self.tree.pack(side='left', fill='both', expand=True)
        scrollbar.pack(side='right', fill='y')

        # Load students
        self.load_students()

    def load_students(self):
        """Load students from database"""
        for item in self.tree.get_children():
            self.tree.delete(item)

        try:
            conn = sqlite3.connect('exam_system.db')
            cursor = conn.cursor()

            cursor.execute("""
                SELECT id, name, class, email, phone
                FROM students
                ORDER BY name
            """)

            students = cursor.fetchall()

            if not students:
                self.tree.insert('', 'end', values=('--', 'No students found', '--', '--', '--'))
                return

            for student in students:
                self.tree.insert('', 'end', values=student)

        except sqlite3.Error as e:
            MessageUtils.show_error(f"Database error: {str(e)}")
        finally:
            if 'conn' in locals():
                conn.close()