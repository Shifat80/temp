import tkinter as tk
from tkinter import ttk
import sqlite3
from utils.message_utils import MessageUtils

class QuestionList:
    """Component for displaying and managing exam questions"""

    def __init__(self, parent, exam_id):
        self.parent = parent
        self.exam_id = exam_id
        self.setup_list()

    def setup_list(self):
        """Set up the question list view"""
        # Create treeview with scrollbar
        tree_frame = ttk.Frame(self.parent, style="Content.TFrame")
        tree_frame.pack(fill='both', expand=True)

        # Add scrollbar
        scrollbar = ttk.Scrollbar(tree_frame)
        scrollbar.pack(side='right', fill='y')

        # Configure columns
        columns = ('ID', 'Question', 'Marks')
        self.tree = ttk.Treeview(
            tree_frame,
            columns=columns,
            show='headings',
            style="Timeline.Treeview"
        )

        # Configure column headings and widths
        self.tree.heading('ID', text='ID')
        self.tree.heading('Question', text='Question')
        self.tree.heading('Marks', text='Marks')

        self.tree.column('ID', width=50)
        self.tree.column('Question', width=500)
        self.tree.column('Marks', width=100)

        # Configure scrollbar
        scrollbar.config(command=self.tree.yview)
        self.tree.config(yscrollcommand=scrollbar.set)

        # Pack the treeview
        self.tree.pack(side='left', fill='both', expand=True)

        # Bind double-click event
        self.tree.bind('<Double-1>', self.edit_question)

        # Load questions
        self.refresh_questions()

    def refresh_questions(self):
        """Refresh the question list"""
        # Clear existing items
        for item in self.tree.get_children():
            self.tree.delete(item)

        try:
            conn = sqlite3.connect('exam_system.db')
            cursor = conn.cursor()

            cursor.execute("""
                SELECT id, question, marks
                FROM questions
                WHERE exam_id = ?
                ORDER BY id
            """, (self.exam_id,))

            questions = cursor.fetchall()

            if questions:
                for question in questions:
                    self.tree.insert('', 'end', values=question)
            else:
                self.tree.insert('', 'end', values=('--', 'No questions added yet', '--'))

        except sqlite3.Error as e:
            MessageUtils.show_error(f"Failed to load questions: {str(e)}")
        finally:
            if 'conn' in locals():
                conn.close()

    def edit_question(self, event=None):
        """Open question editor for selected question"""
        selection = self.tree.selection()
        if not selection:
            return

        question_id = self.tree.item(selection[0])['values'][0]
        if question_id == '--':  # No questions placeholder
            return

        editor_window = tk.Toplevel(self.parent)
        from .question_editor import QuestionEditor
        QuestionEditor(editor_window, question_id, self.refresh_questions)

    def get_question_count(self):
        """Get total number of questions"""
        try:
            conn = sqlite3.connect('exam_system.db')
            cursor = conn.cursor()

            cursor.execute("""
                SELECT COUNT(*)
                FROM questions
                WHERE exam_id = ?
            """, (self.exam_id,))

            count = cursor.fetchone()[0]
            conn.close()
            return count

        except sqlite3.Error:
            return 0