import tkinter as tk
from tkinter import ttk
import sqlite3
from utils.message_utils import MessageUtils

class QuestionEditor:
    """Dialog for editing existing questions"""

    def __init__(self, parent, question_id, callback):
        self.parent = parent
        self.question_id = question_id
        self.callback = callback

        self.setup_dialog()
        self.load_question()

    def setup_dialog(self):
        """Set up the dialog window"""
        self.parent.title("Edit Question")
        self.parent.configure(bg='#0B1437')

        # Center the window
        window_width = 700
        window_height = 600
        screen_width = self.parent.winfo_screenwidth()
        screen_height = self.parent.winfo_screenheight()
        x = (screen_width - window_width) // 2
        y = (screen_height - window_height) // 2
        self.parent.geometry(f"{window_width}x{window_height}+{x}+{y}")

        # Main container
        self.main_frame = ttk.Frame(self.parent, style="Content.TFrame")
        self.main_frame.pack(fill='both', expand=True, padx=20, pady=20)

        # Create form fields
        self.create_form_fields()

        # Create buttons
        self.create_buttons()

    def create_form_fields(self):
        """Create form input fields"""
        # Question text
        ttk.Label(self.main_frame,
                 text="Question:",
                 style="Card.TLabel").pack(anchor='w', pady=(0,5))

        self.question_text = tk.Text(self.main_frame, height=4, width=60)
        self.question_text.pack(fill='x', pady=(0,15))

        # Options frame
        options_frame = ttk.Frame(self.main_frame, style="Card.TFrame")
        options_frame.pack(fill='x', pady=10)

        # Create option entries
        self.options = []
        option_labels = ['A', 'B', 'C', 'D']

        for i, label in enumerate(option_labels):
            option_frame = ttk.Frame(options_frame, style="Card.TFrame")
            option_frame.pack(fill='x', pady=5)

            ttk.Label(option_frame,
                     text=f"Option {label}:",
                     style="Card.TLabel").pack(side='left', padx=(0,10))

            entry = ttk.Entry(option_frame, width=50)
            entry.pack(side='left', fill='x', expand=True)
            self.options.append(entry)

        # Correct answer
        answer_frame = ttk.Frame(self.main_frame, style="Card.TFrame")
        answer_frame.pack(fill='x', pady=15)

        ttk.Label(answer_frame,
                 text="Correct Answer:",
                 style="Card.TLabel").pack(side='left', padx=(0,10))

        self.correct_var = tk.StringVar()
        for i, label in enumerate(option_labels):
            ttk.Radiobutton(answer_frame,
                          text=label,
                          variable=self.correct_var,
                          value=label,
                          style="Custom.TRadiobutton").pack(side='left', padx=10)

        # Marks
        marks_frame = ttk.Frame(self.main_frame, style="Card.TFrame")
        marks_frame.pack(fill='x', pady=15)

        ttk.Label(marks_frame,
                 text="Marks:",
                 style="Card.TLabel").pack(side='left', padx=(0,10))

        self.marks_var = tk.StringVar()
        ttk.Entry(marks_frame,
                 textvariable=self.marks_var,
                 width=10).pack(side='left')

    def create_buttons(self):
        """Create dialog buttons"""
        button_frame = ttk.Frame(self.main_frame, style="Content.TFrame")
        button_frame.pack(fill='x', pady=20)

        ttk.Button(button_frame,
                  text="Save Changes",
                  style="Custom.TButton",
                  command=self.save_changes).pack(side='right', padx=5)

        ttk.Button(button_frame,
                  text="Delete Question",
                  style="Custom.TButton",
                  command=self.delete_question).pack(side='right', padx=5)

        ttk.Button(button_frame,
                  text="Cancel",
                  style="Custom.TButton",
                  command=self.parent.destroy).pack(side='right', padx=5)

    def load_question(self):
        """Load question data from database"""
        try:
            conn = sqlite3.connect('exam_system.db')
            cursor = conn.cursor()

            cursor.execute("""
                SELECT question, option_a, option_b, option_c, option_d,
                       correct_answer, marks
                FROM questions
                WHERE id = ?
            """, (self.question_id,))

            data = cursor.fetchone()
            if data:
                # Set question text
                self.question_text.delete('1.0', tk.END)
                self.question_text.insert('1.0', data[0])

                # Set options
                for i, option in enumerate(data[1:5]):
                    self.options[i].delete(0, tk.END)
                    self.options[i].insert(0, option)

                # Set correct answer
                self.correct_var.set(data[5])

                # Set marks
                self.marks_var.set(str(data[6]))

            conn.close()

        except sqlite3.Error as e:
            MessageUtils.show_error(f"Failed to load question: {str(e)}")

    def save_changes(self):
        """Save question changes to database"""
        # Validate inputs
        question = self.question_text.get('1.0', 'end-1c').strip()
        options = [opt.get().strip() for opt in self.options]
        correct = self.correct_var.get()
        marks = self.marks_var.get()

        if not question or not all(options) or not correct or not marks:
            MessageUtils.show_error("Please fill all fields")
            return

        try:
            marks = int(marks)
            if marks <= 0:
                MessageUtils.show_error("Marks must be a positive number")
                return
        except ValueError:
            MessageUtils.show_error("Marks must be a valid number")
            return

        try:
            conn = sqlite3.connect('exam_system.db')
            cursor = conn.cursor()

            cursor.execute("""
                UPDATE questions
                SET question=?, option_a=?, option_b=?, option_c=?,
                    option_d=?, correct_answer=?, marks=?
                WHERE id=?
            """, (
                question,
                options[0],
                options[1],
                options[2],
                options[3],
                correct,
                marks,
                self.question_id
            ))

            conn.commit()
            conn.close()

            MessageUtils.show_success("Question updated successfully!")
            self.callback()  # Refresh question list
            self.parent.destroy()

        except sqlite3.Error as e:
            MessageUtils.show_error(f"Failed to update question: {str(e)}")

    def delete_question(self):
        """Delete question from database"""
        if not MessageUtils.confirm_action("Are you sure you want to delete this question?"):
            return

        try:
            conn = sqlite3.connect('exam_system.db')
            cursor = conn.cursor()

            cursor.execute("DELETE FROM questions WHERE id=?", (self.question_id,))
            conn.commit()
            conn.close()

            MessageUtils.show_success("Question deleted successfully!")
            self.callback()  # Refresh question list
            self.parent.destroy()

        except sqlite3.Error as e:
            MessageUtils.show_error(f"Failed to delete question: {str(e)}")