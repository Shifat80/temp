import tkinter as tk
from tkinter import ttk
import sqlite3
from utils.message_utils import MessageUtils

class QuestionCreationDialog:
    """Dialog for creating new exam questions"""

    def __init__(self, parent, exam_id, callback):
        self.parent = parent
        self.exam_id = exam_id
        self.callback = callback

        self.setup_dialog()

    def setup_dialog(self):
        """Set up the dialog window"""
        self.parent.title("Add New Question")
        self.parent.configure(bg='#0B1437')

        # Center the window
        window_width = 700
        window_height = 600
        screen_width = self.parent.winfo_screenwidth()
        screen_height = self.parent.winfo_screenheight()
        x = (screen_width - window_width) // 2
        y = (screen_height - window_height) // 2
        self.parent.geometry(f"{window_width}x{window_height}+{x}+{y}")

        # Main container
        self.main_frame = ttk.Frame(self.parent, style="Content.TFrame")
        self.main_frame.pack(fill='both', expand=True, padx=20, pady=20)

        # Create form fields
        self.create_form_fields()

        # Create buttons
        self.create_buttons()

    def create_form_fields(self):
        """Create form input fields"""
        # Question text
        ttk.Label(self.main_frame,
                 text="Question:",
                 style="Card.TLabel").pack(anchor='w', pady=(0,5))

        self.question_text = tk.Text(self.main_frame, height=4, width=60)
        self.question_text.pack(fill='x', pady=(0,15))

        # Options frame
        options_frame = ttk.Frame(self.main_frame, style="Card.TFrame")
        options_frame.pack(fill='x', pady=10)

        # Create option entries
        self.options = []
        option_labels = ['A', 'B', 'C', 'D']

        for i, label in enumerate(option_labels):
            option_frame = ttk.Frame(options_frame, style="Card.TFrame")
            option_frame.pack(fill='x', pady=5)

            ttk.Label(option_frame,
                     text=f"Option {label}:",
                     style="Card.TLabel").pack(side='left', padx=(0,10))

            entry = ttk.Entry(option_frame, width=50)
            entry.pack(side='left', fill='x', expand=True)
            self.options.append(entry)

        # Correct answer
        answer_frame = ttk.Frame(self.main_frame, style="Card.TFrame")
        answer_frame.pack(fill='x', pady=15)

        ttk.Label(answer_frame,
                 text="Correct Answer:",
                 style="Card.TLabel").pack(side='left', padx=(0,10))

        self.correct_var = tk.StringVar()
        for i, label in enumerate(option_labels):
            ttk.Radiobutton(answer_frame,
                          text=label,
                          variable=self.correct_var,
                          value=label,
                          style="Custom.TRadiobutton").pack(side='left', padx=10)

        # Marks
        marks_frame = ttk.Frame(self.main_frame, style="Card.TFrame")
        marks_frame.pack(fill='x', pady=15)

        ttk.Label(marks_frame,
                 text="Marks:",
                 style="Card.TLabel").pack(side='left', padx=(0,10))

        self.marks_var = tk.StringVar(value="1")
        ttk.Entry(marks_frame,
                 textvariable=self.marks_var,
                 width=10).pack(side='left')

    def create_buttons(self):
        """Create dialog buttons"""
        button_frame = ttk.Frame(self.main_frame, style="Content.TFrame")
        button_frame.pack(fill='x', pady=20)

        ttk.Button(button_frame,
                  text="Add Question",
                  style="Custom.TButton",
                  command=self.add_question).pack(side='right', padx=5)

        ttk.Button(button_frame,
                  text="Cancel",
                  style="Custom.TButton",
                  command=self.parent.destroy).pack(side='right', padx=5)

    def add_question(self):
        """Add new question to database"""
        # Validate inputs
        question = self.question_text.get('1.0', 'end-1c').strip()
        options = [opt.get().strip() for opt in self.options]
        correct = self.correct_var.get()
        marks = self.marks_var.get()

        if not question or not all(options) or not correct or not marks:
            MessageUtils.show_error("Please fill all fields")
            return

        try:
            marks = int(marks)
            if marks <= 0:
                MessageUtils.show_error("Marks must be a positive number")
                return
        except ValueError:
            MessageUtils.show_error("Marks must be a valid number")
            return

        try:
            conn = sqlite3.connect('exam_system.db')
            cursor = conn.cursor()

            cursor.execute("""
                INSERT INTO questions (
                    exam_id, question, option_a, option_b,
                    option_c, option_d, correct_answer, marks
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                self.exam_id,
                question,
                options[0],
                options[1],
                options[2],
                options[3],
                correct,
                marks
            ))

            conn.commit()
            conn.close()

            MessageUtils.show_success("Question added successfully!")
            self.callback()  # Refresh question list
            self.parent.destroy()

        except sqlite3.Error as e:
            MessageUtils.show_error(f"Failed to add question: {str(e)}")