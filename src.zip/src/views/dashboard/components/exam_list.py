from tkinter import ttk
import sqlite3
from src.utils.message_utils import MessageUtils

class ExamList:
    """Reusable exam list component"""
    
    def __init__(self, parent, style="Timeline.Treeview"):
        self.parent = parent
        self.style = style
        self.setup_treeview()
    
    def setup_treeview(self):
        """Set up the exam list treeview"""
        columns = ('ID', 'Title', 'Subject', 'Duration (min)')
        self.tree = ttk.Treeview(
            self.parent,
            columns=columns,
            show='headings',
            style=self.style
        )
        
        # Configure columns
        widths = {'ID': 80, 'Title': 300, 'Subject': 200, 'Duration (min)': 150}
        for col, width in widths.items():
            self.tree.heading(col, text=col)
            self.tree.column(col, width=width, anchor='center')
        
        # Add scrollbar
        scrollbar = ttk.Scrollbar(self.parent, orient='vertical', command=self.tree.yview)
        self.tree.configure(yscrollcommand=scrollbar.set)
        
        # Pack widgets
        self.tree.pack(side='left', fill='both', expand=True)
        scrollbar.pack(side='right', fill='y')
    
    def load_exams(self, user_id, is_student=True):
        """Load exams based on user type"""
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        try:
            conn = sqlite3.connect('exam_system.db')
            cursor = conn.cursor()
            
            if is_student:
                # Get available exams for student
                cursor.execute("""
                    SELECT id, title, subject, duration 
                    FROM exams 
                    WHERE id NOT IN (
                        SELECT exam_id FROM results WHERE student_id = ?
                    )
                    ORDER BY id DESC
                """, (user_id,))
            else:
                # Get exams created by teacher
                cursor.execute("""
                    SELECT id, title, subject, duration 
                    FROM exams 
                    WHERE created_by = ?
                    ORDER BY id DESC
                """, (user_id,))
            
            exams = cursor.fetchall()
            
            if not exams:
                self.tree.insert('', 'end', values=('-', 'No exams available', '-', '-'))
                return
            
            for exam in exams:
                self.tree.insert('', 'end', values=exam)
                
        except sqlite3.Error as e:
            MessageUtils.show_error(f"Database error: {str(e)}")
        finally:
            if 'conn' in locals():
                conn.close()
    
    def get_selected_exam(self):
        """Get the selected exam ID"""
        selection = self.tree.selection()
        if not selection:
            return None
        return self.tree.item(selection[0])['values'][0]