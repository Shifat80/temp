import tkinter as tk
from tkinter import ttk, filedialog
import sqlite3
from datetime import datetime
from src.utils.message_utils import MessageUtils

class ProgressReport:
    """Component for generating student progress reports"""
    
    def __init__(self, student_id):
        self.student_id = student_id
    
    def generate_report(self):
        """Generate and save progress report"""
        try:
            conn = sqlite3.connect('exam_system.db')
            cursor = conn.cursor()
            
            # Get student info
            cursor.execute("""
                SELECT name, class
                FROM students
                WHERE id = ?
            """, (self.student_id,))
            
            student = cursor.fetchone()
            
            # Get exam results
            cursor.execute("""
                SELECT e.title, e.subject, r.score, r.date
                FROM results r
                JOIN exams e ON r.exam_id = e.id
                WHERE r.student_id = ?
                ORDER BY r.date DESC
            """, (self.student_id,))
            
            results = cursor.fetchall()
            
            if not results:
                MessageUtils.show_warning("No exam results available for report")
                return
            
            # Calculate statistics
            total_exams = len(results)
            avg_score = sum(result[2] for result in results) / total_exams
            
            # Generate report content
            report = f"""Progress Report
            
Student Name: {student[0]}
Class: {student[1]}
Report Date: {datetime.now().strftime('%Y-%m-%d %H:%M')}

Summary:
Total Exams Taken: {total_exams}
Average Score: {avg_score:.2f}%

Detailed Results:
"""
            
            for result in results:
                report += f"\nExam: {result[0]}"
                report += f"\nSubject: {result[1]}"
                report += f"\nScore: {result[2]:.2f}%"
                report += f"\nDate: {result[3]}\n"
            
            # Save report
            file_path = filedialog.asksaveasfilename(
                defaultextension=".txt",
                filetypes=[("Text files", "*.txt")],
                initialfile=f"progress_report_{student[0].lower().replace(' ', '_')}.txt"
            )
            
            if file_path:
                with open(file_path, 'w') as f:
                    f.write(report)
                MessageUtils.show_success("Progress report generated successfully!")
            
            conn.close()
            
        except sqlite3.Error as e:
            MessageUtils.show_error(f"Failed to generate report: {str(e)}")
        except IOError as e:
            MessageUtils.show_error(f"Failed to save report: {str(e)}")