import tkinter as tk
from tkinter import ttk, filedialog
from PIL import Image, ImageTk
import io
import sqlite3
from src.utils.message_utils import MessageUtils

class ProfileView:
    """Component for displaying and editing user profile"""
    
    def __init__(self, parent, user_id, is_student=True):
        self.parent = parent
        self.user_id = user_id
        self.is_student = is_student
        self.setup_view()
    
    def setup_view(self):
        """Set up the profile view layout"""
        # Create two columns
        self.columns_frame = ttk.Frame(self.parent, style="Content.TFrame")
        self.columns_frame.pack(fill='both', expand=True)
        
        # Left column - Profile Picture
        self.setup_profile_picture()
        
        # Right column - Profile Information
        self.setup_profile_info()
        
        # Load profile data
        self.load_profile_data()
    
    def setup_profile_picture(self):
        """Set up the profile picture section"""
        left_column = ttk.Frame(self.columns_frame, style="Card.TFrame")
        left_column.pack(side='left', padx=(0, 20), fill='both')
        
        # Profile picture frame
        pic_frame = ttk.Frame(left_column, style="Card.TFrame")
        pic_frame.pack(pady=20, padx=20)
        
        self.image_label = ttk.Label(pic_frame, background='#112240')
        self.image_label.pack(padx=10, pady=10)
        
        ttk.Button(left_column,
                  text="Upload Photo",
                  style="Custom.TButton",
                  command=self.upload_profile_pic).pack(pady=10)
    
    def setup_profile_info(self):
        """Set up the profile information section"""
        self.right_column = ttk.Frame(self.columns_frame, style="Card.TFrame")
        self.right_column.pack(side='left', fill='both', expand=True)
        
        # Info frame
        self.info_frame = ttk.Frame(self.right_column, style="Card.TFrame")
        self.info_frame.pack(fill='both', expand=True, padx=20, pady=20)
    
    def load_profile_data(self):
        """Load profile data from database"""
        conn = sqlite3.connect('exam_system.db')
        cursor = conn.cursor()
        
        try:
            table = "students" if self.is_student else "teachers"
            cursor.execute(f"""
                SELECT name, {table}.class if table == 'students' else subject}, 
                       email, phone, bio, profile_pic
                FROM {table}
                WHERE id = ?
            """, (self.user_id,))
            
            self.profile_data = cursor.fetchone()
            
            if self.profile_data:
                self.display_profile_data()
                self.display_profile_picture()
                
        except sqlite3.Error as e:
            MessageUtils.show_error(f"Failed to load profile: {str(e)}")
        finally:
            conn.close()
    
    def display_profile_data(self):
        """Display profile information"""
        # Clear existing info
        for widget in self.info_frame.winfo_children():
            widget.destroy()
        
        # Helper function to create info rows
        def create_info_row(label_text, value, row):
            ttk.Label(self.info_frame,
                     text=label_text,
                     style="Card.TLabel").grid(row=row, column=0, sticky='w', pady=10)
            
            ttk.Label(self.info_frame,
                     text=value if value else "Not set",
                     style="Card.TLabel").grid(row=row, column=1, sticky='w', padx=20, pady=10)
        
        # Display profile information
        create_info_row("Full Name:", self.profile_data[0], 0)
        create_info_row("Class:" if self.is_student else "Subject:", self.profile_data[1], 1)
        create_info_row("Email:", self.profile_data[2], 2)
        create_info_row("Phone:", self.profile_data[3], 3)
        
        # Bio section
        ttk.Label(self.info_frame,
                 text="About Me:",
                 style="Card.TLabel").grid(row=4, column=0, sticky='w', pady=(20,10))
        
        bio_text = self.profile_data[4] if self.profile_data[4] else "No bio added yet."
        ttk.Label(self.info_frame,
                 text=bio_text,
                 style="Card.TLabel",
                 wraplength=400).grid(row=5, column=0, columnspan=2, sticky='w', pady=10)
    
    def display_profile_picture(self):
        """Display profile picture"""
        if self.profile_data[5]:  # If profile picture exists
            try:
                image_data = io.BytesIO(self.profile_data[5])
                pil_image = Image.open(image_data)
                
                # Resize image while maintaining aspect ratio
                target_size = (200, 200)
                pil_image.thumbnail(target_size, Image.Resampling.LANCZOS)
                
                # Convert PIL image to PhotoImage
                photo = ImageTk.PhotoImage(pil_image)
                
                # Store the photo as an attribute to prevent garbage collection
                self.profile_photo = photo
                
                # Update image label
                self.image_label.configure(image=photo)
            except Exception:
                self.show_default_picture()
        else:
            self.show_default_picture()
    
    def show_default_picture(self):
        """Show default profile picture"""
        self.image_label.configure(
            text="👤",
            font=('Segoe UI', 48),
            foreground='#E6F1FF'
        )
    
    def upload_profile_pic(self):
        """Handle profile picture upload"""
        file_path = filedialog.askopenfilename(
            title="Select Profile Picture",
            filetypes=[("Image files", "*.png *.jpg *.jpeg *.gif *.bmp")]
        )
        
        if file_path:
            try:
                # Open and resize image
                with Image.open(file_path) as img:
                    img.thumbnail((800, 800), Image.Resampling.LANCZOS)
                    
                    # Convert image to bytes
                    img_byte_arr = io.BytesIO()
                    img.save(img_byte_arr, format=img.format)
                    img_byte_arr = img_byte_arr.getvalue()
                
                # Save to database
                conn = sqlite3.connect('exam_system.db')
                cursor = conn.cursor()
                table = "students" if self.is_student else "teachers"
                cursor.execute(f"UPDATE {table} SET profile_pic=? WHERE id=?",
                             (img_byte_arr, self.user_id))
                conn.commit()
                conn.close()
                
                MessageUtils.show_success("Profile picture updated successfully!")
                self.load_profile_data()  # Refresh display
                
            except Exception as e:
                MessageUtils.show_error(f"Failed to upload profile picture: {str(e)}")
    
    def edit_profile(self):
        """Show edit profile dialog"""
        edit_window = tk.Toplevel(self.parent)
        EditProfileDialog(edit_window, self.user_id, self.is_student, self.refresh_profile)
    
    def refresh_profile(self):
        """Refresh profile data and display"""
        self.load_profile_data()