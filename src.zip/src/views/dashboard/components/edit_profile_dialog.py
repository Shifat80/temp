import tkinter as tk
from tkinter import ttk
import sqlite3
from src.utils.message_utils import MessageUtils

class EditProfileDialog:
    """Dialog for editing user profile information"""
    
    def __init__(self, parent, user_id, is_student, callback):
        self.parent = parent
        self.user_id = user_id
        self.is_student = is_student
        self.callback = callback
        
        self.setup_dialog()
        self.load_current_data()
    
    def setup_dialog(self):
        """Set up the dialog window"""
        self.parent.title("Edit Profile")
        self.parent.configure(bg='#0B1437')
        
        # Center the window
        window_width = 500
        window_height = 600
        screen_width = self.parent.winfo_screenwidth()
        screen_height = self.parent.winfo_screenheight()
        x = (screen_width - window_width) // 2
        y = (screen_height - window_height) // 2
        self.parent.geometry(f"{window_width}x{window_height}+{x}+{y}")
        
        # Main container
        self.main_frame = ttk.Frame(self.parent, style="Content.TFrame")
        self.main_frame.pack(fill='both', expand=True, padx=20, pady=20)
        
        # Header
        ttk.Label(self.main_frame,
                 text="Edit Profile",
                 style="Title.TLabel").pack(pady=(0,20))
        
        # Form frame
        self.form_frame = ttk.Frame(self.main_frame, style="Card.TFrame")
        self.form_frame.pack(fill='both', expand=True, padx=20, pady=20)
        
        # Create form fields
        self.create_form_fields()
        
        # Buttons
        self.create_buttons()
    
    def create_form_fields(self):
        """Create form input fields"""
        # Helper function to create a field
        def create_field(label_text, row, is_text_area=False):
            ttk.Label(self.form_frame,
                     text=label_text,
                     style="Card.TLabel").grid(row=row, column=0, sticky='w', pady=(10,5))
            
            if is_text_area:
                text_widget = tk.Text(self.form_frame, height=4, width=40)
                text_widget.grid(row=row+1, column=0, sticky='ew', pady=(0,10))
                return text_widget
            else:
                var = tk.StringVar()
                entry = ttk.Entry(self.form_frame, textvariable=var, width=40)
                entry.grid(row=row+1, column=0, sticky='ew', pady=(0,10))
                return var
        
        # Create fields
        self.name_var = create_field("Full Name", 0)
        if self.is_student:
            self.class_var = create_field("Class", 2)
        else:
            self.subject_var = create_field("Subject", 2)
        self.email_var = create_field("Email", 4)
        self.phone_var = create_field("Phone", 6)
        self.bio_text = create_field("About Me", 8, True)
    
    def create_buttons(self):
        """Create dialog buttons"""
        button_frame = ttk.Frame(self.main_frame, style="Content.TFrame")
        button_frame.pack(fill='x', pady=20)
        
        ttk.Button(button_frame,
                  text="Save Changes",
                  style="Custom.TButton",
                  command=self.save_changes).pack(side='right', padx=5)
        
        ttk.Button(button_frame,
                  text="Cancel",
                  style="Custom.TButton",
                  command=self.parent.destroy).pack(side='right', padx=5)
    
    def load_current_data(self):
        """Load current profile data"""
        conn = sqlite3.connect('exam_system.db')
        cursor = conn.cursor()
        
        try:
            table = "students" if self.is_student else "teachers"
            cursor.execute(f"""
                SELECT name, {table}.class if table == 'students' else subject}, 
                       email, phone, bio
                FROM {table}
                WHERE id = ?
            """, (self.user_id,))
            
            data = cursor.fetchone()
            if data:
                self.name_var.set(data[0])
                if self.is_student:
                    self.class_var.set(data[1])
                else:
                    self.subject_var.set(data[1])
                self.email_var.set(data[2] or "")
                self.phone_var.set(data[3] or "")
                self.bio_text.delete('1.0', tk.END)
                self.bio_text.insert('1.0', data[4] or "")
                
        except sqlite3.Error as e:
            MessageUtils.show_error(f"Failed to load profile data: {str(e)}")
        finally:
            conn.close()
    
    def save_changes(self):
        """Save profile changes to database"""
        try:
            conn = sqlite3.connect('exam_system.db')
            cursor = conn.cursor()
            
            table = "students" if self.is_student else "teachers"
            class_or_subject = self.class_var.get() if self.is_student else self.subject_var.get()
            
            cursor.execute(f"""
                UPDATE {table}
                SET name=?, {'class' if self.is_student else 'subject'}=?, 
                    email=?, phone=?, bio=?
                WHERE id=?
            """, (
                self.name_var.get(),
                class_or_subject,
                self.email_var.get(),
                self.phone_var.get(),
                self.bio_text.get('1.0', 'end-1c'),
                self.user_id
            ))
            
            conn.commit()
            conn.close()
            
            MessageUtils.show_success("Profile updated successfully!")
            self.callback()  # Refresh profile view
            self.parent.destroy()
            
        except sqlite3.Error as e:
            MessageUtils.show_error(f"Failed to update profile: {str(e)}")