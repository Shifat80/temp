import tkinter as tk
from tkinter import ttk
import sqlite3
from src.utils.message_utils import MessageUtils

class ExamCreationDialog:
    """Dialog for creating new exams"""
    
    def __init__(self, parent, teacher_id, callback):
        self.parent = parent
        self.teacher_id = teacher_id
        self.callback = callback
        
        self.setup_dialog()
    
    def setup_dialog(self):
        """Set up the dialog window"""
        self.parent.title("Create New Exam")
        self.parent.configure(bg='#0B1437')
        
        # Center the window
        window_width = 600
        window_height = 400
        screen_width = self.parent.winfo_screenwidth()
        screen_height = self.parent.winfo_screenheight()
        x = (screen_width - window_width) // 2
        y = (screen_height - window_height) // 2
        self.parent.geometry(f"{window_width}x{window_height}+{x}+{y}")
        
        # Main container
        self.main_frame = ttk.Frame(self.parent, style="Content.TFrame")
        self.main_frame.pack(fill='both', expand=True, padx=20, pady=20)
        
        # Header
        ttk.Label(self.main_frame,
                 text="Create New Exam",
                 style="Title.TLabel").pack(pady=(0,20))
        
        # Form frame
        self.form_frame = ttk.Frame(self.main_frame, style="Card.TFrame")
        self.form_frame.pack(fill='both', expand=True, padx=20, pady=20)
        
        # Create form fields
        self.create_form_fields()
        
        # Buttons
        self.create_buttons()
    
    def create_form_fields(self):
        """Create form input fields"""
        # Title
        ttk.Label(self.form_frame,
                 text="Exam Title:",
                 style="Card.TLabel").pack(anchor='w', pady=(0,5))
        self.title_var = tk.StringVar()
        ttk.Entry(self.form_frame,
                 textvariable=self.title_var,
                 width=50).pack(fill='x', pady=(0,15))
        
        # Subject
        ttk.Label(self.form_frame,
                 text="Subject:",
                 style="Card.TLabel").pack(anchor='w', pady=(0,5))
        self.subject_var = tk.StringVar()
        ttk.Entry(self.form_frame,
                 textvariable=self.subject_var,
                 width=50).pack(fill='x', pady=(0,15))
        
        # Duration
        ttk.Label(self.form_frame,
                 text="Duration (minutes):",
                 style="Card.TLabel").pack(anchor='w', pady=(0,5))
        self.duration_var = tk.StringVar()
        ttk.Entry(self.form_frame,
                 textvariable=self.duration_var,
                 width=10).pack(anchor='w', pady=(0,15))
        
        # Total marks
        ttk.Label(self.form_frame,
                 text="Total Marks:",
                 style="Card.TLabel").pack(anchor='w', pady=(0,5))
        self.marks_var = tk.StringVar(value="100")
        ttk.Entry(self.form_frame,
                 textvariable=self.marks_var,
                 width=10).pack(anchor='w')
    
    def create_buttons(self):
        """Create dialog buttons"""
        button_frame = ttk.Frame(self.main_frame, style="Content.TFrame")
        button_frame.pack(fill='x', pady=20)
        
        ttk.Button(button_frame,
                  text="Create Exam",
                  style="Custom.TButton",
                  command=self.create_exam).pack(side='right', padx=5)
        
        ttk.Button(button_frame,
                  text="Cancel",
                  style="Custom.TButton",
                  command=self.parent.destroy).pack(side='right', padx=5)
    
    def create_exam(self):
        """Create new exam in database"""
        # Validate inputs
        if not all([self.title_var.get(), self.subject_var.get(), 
                   self.duration_var.get(), self.marks_var.get()]):
            MessageUtils.show_error("Please fill all fields")
            return
        
        try:
            duration = int(self.duration_var.get())
            total_marks = int(self.marks_var.get())
            
            if duration <= 0 or total_marks <= 0:
                MessageUtils.show_error("Duration and marks must be positive numbers")
                return
                
        except ValueError:
            MessageUtils.show_error("Duration and marks must be valid numbers")
            return
        
        try:
            conn = sqlite3.connect('exam_system.db')
            cursor = conn.cursor()
            
            cursor.execute("""
                INSERT INTO exams (title, subject, duration, total_marks, created_by)
                VALUES (?, ?, ?, ?, ?)
            """, (
                self.title_var.get(),
                self.subject_var.get(),
                duration,
                total_marks,
                self.teacher_id
            ))
            
            conn.commit()
            conn.close()
            
            MessageUtils.show_success("Exam created successfully!")
            self.callback()  # Refresh exam list
            self.parent.destroy()
            
        except sqlite3.Error as e:
            MessageUtils.show_error(f"Failed to create exam: {str(e)}")