from tkinter import ttk
import sqlite3
from datetime import datetime
from src.utils.message_utils import MessageUtils

class ResultsList:
    """Reusable results list component"""
    
    def __init__(self, parent, style="Timeline.Treeview"):
        self.parent = parent
        self.style = style
        self.setup_treeview()
    
    def setup_treeview(self):
        """Set up the results list treeview"""
        columns = ('ID', 'Student', 'Exam', 'Score (%)', 'Date')
        self.tree = ttk.Treeview(
            self.parent,
            columns=columns,
            show='headings',
            style=self.style
        )
        
        # Configure columns
        widths = {'ID': 50, 'Student': 200, 'Exam': 200, 'Score (%)': 100, 'Date': 150}
        for col, width in widths.items():
            self.tree.heading(col, text=col)
            self.tree.column(col, width=width)
        
        # Add scrollbar
        scrollbar = ttk.Scrollbar(self.parent, orient='vertical', command=self.tree.yview)
        self.tree.configure(yscrollcommand=scrollbar.set)
        
        # Pack widgets
        self.tree.pack(side='left', fill='both', expand=True)
        scrollbar.pack(side='right', fill='y')
    
    def load_results(self, user_id, is_student=True):
        """Load results based on user type"""
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        try:
            conn = sqlite3.connect('exam_system.db')
            cursor = conn.cursor()
            
            if is_student:
                # Get student's results
                cursor.execute("""
                    SELECT r.id, s.name, e.title, r.score, r.date
                    FROM results r
                    JOIN students s ON r.student_id = s.id
                    JOIN exams e ON r.exam_id = e.id
                    WHERE r.student_id = ?
                    ORDER BY r.date DESC
                """, (user_id,))
            else:
                # Get results for teacher's exams
                cursor.execute("""
                    SELECT r.id, s.name, e.title, r.score, r.date
                    FROM results r
                    JOIN students s ON r.student_id = s.id
                    JOIN exams e ON r.exam_id = e.id
                    WHERE e.created_by = ?
                    ORDER BY r.date DESC
                """, (user_id,))
            
            results = cursor.fetchall()
            
            if not results:
                self.tree.insert('', 'end', values=('--', 'No results available', '--', '--', '--'))
                return
            
            for result in results:
                # Format date and score
                date_obj = datetime.strptime(result[4], '%Y-%m-%d %H:%M:%S')
                formatted_date = date_obj.strftime('%Y-%m-%d %H:%M')
                formatted_score = f"{float(result[3]):.2f}"
                
                values = (
                    result[0],
                    result[1],
                    result[2],
                    formatted_score,
                    formatted_date
                )
                self.tree.insert('', 'end', values=values)
                
        except sqlite3.Error as e:
            MessageUtils.show_error(f"Database error: {str(e)}")
        finally:
            if 'conn' in locals():
                conn.close()