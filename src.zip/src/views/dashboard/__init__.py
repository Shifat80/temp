from .student_dashboard import StudentDashboard
from .teacher_dashboard import TeacherDashboard

__all__ = ['StudentDashboard', 'TeacherDashboard']