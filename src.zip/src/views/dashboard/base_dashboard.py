import tkinter as tk
from tkinter import ttk
from utils.styles import StyleConfig
from utils.message_utils import MessageUtils

class BaseDashboard:
    """Base class for dashboard views with common functionality"""

    def __init__(self, root, user_id, login_window):
        self.root = root
        self.user_id = user_id
        self.login_window = login_window
        self.current_page = None

        # Configure window
        self.root.title("Dashboard")
        self.root.state('zoomed')

        # Apply styles
        self.style = ttk.Style()
        StyleConfig.configure_styles(self.style)

        # Create main layout
        self.setup_layout()

    def setup_layout(self):
        """Create the basic dashboard layout"""
        # Main container
        self.main_container = ttk.Frame(self.root, style="Content.TFrame")
        self.main_container.pack(fill='both', expand=True)

        # Sidebar
        self.sidebar = ttk.Frame(self.main_container, style="Sidebar.TFrame", width=250)
        self.sidebar.pack(side='left', fill='y')
        self.sidebar.pack_propagate(False)

        # Content area
        self.content_frame = ttk.Frame(self.main_container, style="Content.TFrame")
        self.content_frame.pack(side='left', fill='both', expand=True)

    def create_nav_button(self, text, command):
        """Create a navigation button in the sidebar"""
        btn = ttk.Button(
            self.sidebar,
            text=text,
            style="NavButton.TButton",
            command=command
        )
        btn.pack(fill='x', pady=2)
        return btn

    def clear_content(self):
        """Clear the content area"""
        for widget in self.content_frame.winfo_children():
            widget.destroy()

    def logout(self):
        """Handle logout"""
        if MessageUtils.confirm_action("Are you sure you want to logout?"):
            self.root.destroy()
            self.login_window.deiconify()