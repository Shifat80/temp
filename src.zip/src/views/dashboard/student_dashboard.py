import tkinter as tk
from tkinter import ttk
from datetime import datetime
import sqlite3
from .base_dashboard import BaseDashboard
from .components import ExamList, ResultsList
from utils.message_utils import MessageUtils
from views.exam_interface import ExamInterface

class StudentDashboard(BaseDashboard):
    def __init__(self, root, student_id, login_window):
        super().__init__(root, student_id, login_window)

        # Load student info
        self.load_student_info()

        # Setup dashboard components
        self.setup_sidebar()
        self.show_available_exams()  # Default view

    def load_student_info(self):
        """Load student information from database"""
        conn = sqlite3.connect('exam_system.db')
        cursor = conn.cursor()
        cursor.execute("SELECT name, class FROM students WHERE id=?", (self.user_id,))
        self.student_info = cursor.fetchone()
        conn.close()

    def setup_sidebar(self):
        """Setup sidebar with student information and navigation"""
        # Header
        header_frame = ttk.Frame(self.sidebar, style="Sidebar.TFrame")
        header_frame.pack(fill='x', pady=(30, 20), padx=20)

        ttk.Label(header_frame,
                 text="Student Portal",
                 style="Title.TLabel").pack(anchor='w')

        ttk.Label(header_frame,
                 text="Manage your exams and results",
                 style="Subtitle.TLabel").pack(anchor='w', pady=(5,0))

        # Navigation buttons
        self.create_nav_button("📝 Available Exams", self.show_available_exams)
        self.create_nav_button("📊 My Results", self.show_results)
        self.create_nav_button("👤 My Profile", self.show_profile)

        # Profile section
        profile_frame = ttk.Frame(self.sidebar, style="Sidebar.TFrame")
        profile_frame.pack(side='bottom', fill='x', pady=20, padx=20)

        ttk.Label(profile_frame,
                 text=self.student_info[0],
                 style="Card.TLabel").pack(anchor='w')

        ttk.Label(profile_frame,
                 text=f"Class {self.student_info[1]}",
                 style="Subtitle.TLabel").pack(anchor='w')

        self.create_nav_button("🚪 Logout", self.logout)

    def show_available_exams(self):
        """Display available exams view"""
        self.clear_content()

        # Header
        header_frame = ttk.Frame(self.content_frame, style="Content.TFrame")
        header_frame.pack(fill='x', pady=(0, 20))

        ttk.Label(header_frame,
                 text="Available Exams",
                 style="Title.TLabel").pack(side='left')

        # Exam list
        list_frame = ttk.Frame(self.content_frame, style="Content.TFrame")
        list_frame.pack(fill='both', expand=True)

        self.exam_list = ExamList(list_frame)
        self.exam_list.load_exams(self.user_id, is_student=True)

        # Start exam button
        button_frame = ttk.Frame(self.content_frame, style="Content.TFrame")
        button_frame.pack(fill='x', pady=20)

        ttk.Button(button_frame,
                  text="Start Selected Exam",
                  style="Custom.TButton",
                  command=self.start_exam).pack(side='right')

    def show_results(self):
        """Display exam results view"""
        self.clear_content()

        # Header
        header_frame = ttk.Frame(self.content_frame, style="Content.TFrame")
        header_frame.pack(fill='x', pady=(0, 20))

        ttk.Label(header_frame,
                 text="My Results",
                 style="Title.TLabel").pack(side='left')

        ttk.Button(header_frame,
                  text="Print Progress Report",
                  style="Custom.TButton",
                  command=self.generate_progress_report).pack(side='right')

        # Results list
        list_frame = ttk.Frame(self.content_frame, style="Content.TFrame")
        list_frame.pack(fill='both', expand=True)

        self.results_list = ResultsList(list_frame)
        self.results_list.load_results(self.user_id, is_student=True)

    def show_profile(self):
        """Display student profile view"""
        self.clear_content()

        # Profile content implementation
        # (Profile view implementation would go here)
        pass

    def start_exam(self):
        """Start selected exam"""
        exam_id = self.exam_list.get_selected_exam()
        if not exam_id:
            MessageUtils.show_error("Please select an exam")
            return

        # Hide dashboard and show exam interface
        self.root.withdraw()
        exam_window = tk.Toplevel()
        exam = ExamInterface(exam_window, self.user_id, exam_id)

        # Handle exam window closing
        exam_window.protocol("WM_DELETE_WINDOW",
                           lambda: [exam_window.destroy(),
                                  self.root.deiconify(),
                                  self.refresh_views()])

    def refresh_views(self):
        """Refresh all dynamic content"""
        if hasattr(self, 'exam_list'):
            self.exam_list.load_exams(self.user_id, is_student=True)
        if hasattr(self, 'results_list'):
            self.results_list.load_results(self.user_id, is_student=True)

    def generate_progress_report(self):
        """Generate and save progress report"""
        # Progress report generation implementation
        # (Report generation code would go here)
        pass