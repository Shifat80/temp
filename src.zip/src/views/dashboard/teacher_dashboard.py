import tkinter as tk
from tkinter import ttk
import sqlite3
from .base_dashboard import BaseDashboard
from .components import ExamList, ResultsList
from .components.student_management.student_list import StudentList
from .components.student_management.student_details import StudentDetails
from .components.exam_creation import ExamCreationDialog
from .components.question_management import QuestionList, QuestionCreationDialog
from utils.message_utils import MessageUtils

class TeacherDashboard(BaseDashboard):
    def __init__(self, root, teacher_id, login_window):
        super().__init__(root, teacher_id, login_window)

        # Load teacher info
        self.load_teacher_info()

        # Setup dashboard components
        self.setup_sidebar()
        self.show_exams()  # Default view

    def show_students(self):
        """Display student management view"""
        self.clear_content()

        # Header
        header_frame = ttk.Frame(self.content_frame, style="Content.TFrame")
        header_frame.pack(fill='x', pady=(0, 20))

        ttk.Label(header_frame,
                 text="Student Management",
                 style="Title.TLabel").pack(side='left')

        # Student list
        list_frame = ttk.Frame(self.content_frame, style="Content.TFrame")
        list_frame.pack(fill='both', expand=True)

        self.student_list = StudentList(list_frame)

        # Double click to view details
        self.student_list.tree.bind('<Double-1>', self.view_student_details)

    def view_student_details(self, event=None):
        """Show student details dialog"""
        selection = self.student_list.tree.selection()
        if not selection:
            return

        student_id = self.student_list.tree.item(selection[0])['values'][0]
        if student_id == '--':  # No students placeholder
            return

        details_window = tk.Toplevel(self.root)
        StudentDetails(details_window, student_id)

    def create_exam(self):
        """Show create exam dialog"""
        dialog = tk.Toplevel(self.root)
        ExamCreationDialog(dialog, self.user_id, self.refresh_exams)

    def manage_questions(self, exam_id):
        """Show question management dialog"""
        dialog = tk.Toplevel(self.root)
        questions = QuestionList(dialog, exam_id)

        # Add question button
        ttk.Button(dialog,
                  text="Add Question",
                  style="Custom.TButton",
                  command=lambda: self.add_question(exam_id, questions.refresh_questions)
                  ).pack(pady=10)

    def add_question(self, exam_id, callback):
        """Show add question dialog"""
        dialog = tk.Toplevel(self.root)
        QuestionCreationDialog(dialog, exam_id, callback)

    def refresh_exams(self):
        """Refresh exam list"""
        if hasattr(self, 'exam_list'):
            self.exam_list.load_exams(self.user_id, is_student=False)